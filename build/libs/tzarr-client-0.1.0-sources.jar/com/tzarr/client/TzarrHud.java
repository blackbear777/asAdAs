package com.tzarr.client;

import net.fabricmc.fabric.api.client.rendering.v1.HudRenderCallback;
import net.minecraft.class_2561;
import net.minecraft.class_310;

public final class TzarrHud {

    private TzarrHud() {}

    public static void init() {

        HudRenderCallback.EVENT.register((drawContext, tickDelta) -> {

            if (!TzarrClient.hudEnabled) {
                return;
            }

            class_310 client = class_310.method_1551();

            if (client.field_1724 == null) {
                return;
            }

            int x = 8;
            int y = 8;

            drawContext.method_27535(
                    client.field_1772,
                    class_2561.method_43470("TZARR CLIENT"),
                    x,
                    y,
                    0xFFFFFF
            );

            drawContext.method_27535(
                    client.field_1772,
                    class_2561.method_43470("CPS: " + CpsTracker.getCps()),
                    x,
                    y + 12,
                    0xFFFFFF
            );
        });
    }
}
