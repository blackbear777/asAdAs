package com.tzarr.client;

import net.fabricmc.api.ClientModInitializer;
import net.fabricmc.fabric.api.client.event.lifecycle.v1.ClientTickEvents;
import net.fabricmc.fabric.api.client.keybinding.v1.KeyBindingHelper;
import net.minecraft.class_304;
import net.minecraft.class_3675;
import org.lwjgl.glfw.GLFW;

public class TzarrClient implements ClientModInitializer {

    public static class_304 toggleHud;
    public static class_304 resetCps;

    public static boolean hudEnabled = true;

    @Override
    public void onInitializeClient() {

        toggleHud = KeyBindingHelper.registerKeyBinding(
                new class_304(
                        "key.tzarr.toggle_hud",
                        class_3675.class_307.field_1668,
                        GLFW.GLFW_KEY_RIGHT_SHIFT,
                        "category.tzarr"
                )
        );

        resetCps = KeyBindingHelper.registerKeyBinding(
                new class_304(
                        "key.tzarr.reset_cps",
                        class_3675.class_307.field_1668,
                        GLFW.GLFW_KEY_R,
                        "category.tzarr"
                )
        );

        ClientTickEvents.END_CLIENT_TICK.register(client -> {

            while (toggleHud.method_1436()) {
                hudEnabled = !hudEnabled;
            }

            while (resetCps.method_1436()) {
                CpsTracker.reset();
            }
        });

        TzarrHud.init();
    }
}
